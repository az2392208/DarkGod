/****************************************************
    文件：MainCityMap.cs
	作者：SIKI学院——Plane
    邮箱: 1785275942@qq.com
    日期：2018/12/17 3:45:42
	功能：主城地图数据
*****************************************************/

using UnityEngine;

public class MainCityMap : MonoBehaviour {
    public Transform[] NpcPosTrans;
}